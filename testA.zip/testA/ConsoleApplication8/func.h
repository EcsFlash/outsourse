#pragma once
#include <iostream>
#include "Class1.h"
#include "Class2.h"

using namespace std;

void func(const Class1& A)
{
	cout << A.a << ' ' << A.b;
}

void func(const Class2& B)
{
	cout << B.a << ' '<< B.b;
}