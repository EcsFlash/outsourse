#pragma once

#include "func.h"

class Class2
{
	int a, b;
public:
	Class2(int A, int B) :a(A), b(B) {};

	friend void func(const Class2&);
};