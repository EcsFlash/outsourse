#pragma once
//Class1.h


#include "func.h"

class Class1
{
	int a, b;
public:
	Class1(int A, int B) :a(A), b(B) {};

	friend void func(const Class1&);
};